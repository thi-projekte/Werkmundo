import "./dashboard.css";

import { DashboardOverview } from "@/features/dashboard/components/DashboardOverview";
import { useDashboard } from "@/features/dashboard/hooks/useDashboard";
import {
  Mic,
  Plus,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { getCustomers, type CustomerProfile } from "@/services/userService";

export const DashboardView = () => {
  const [offerMode, setOfferMode] = useState<"voice" | "text">("voice");
  const [offerText, setOfferText] = useState("");
  const [customers, setCustomers] = useState<CustomerProfile[]>([]);
  const [customersError, setCustomersError] = useState<string | null>(null);
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const { data, loading, error } = useDashboard();
  const location = useLocation();
  const navigate = useNavigate();
  const notice =
    location.state &&
    typeof location.state === "object" &&
    "notice" in location.state &&
    typeof location.state.notice === "string"
      ? location.state.notice
      : null;

  useEffect(() => {
    let cancelled = false;
    void getCustomers()
      .then((result) => {
        if (!cancelled) setCustomers(result);
      })
      .catch((customerError: unknown) => {
        if (!cancelled) {
          const message =
            customerError instanceof Error
              ? customerError.message
              : "Unbekannter Fehler";
          setCustomersError(`Kunden konnten nicht geladen werden: ${message}`);
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="dashboard-page wm-dashboard">
      {notice && (
        <p className="wm-dashboard-feedback wm-dashboard-success" role="status">
          {notice}
        </p>
      )}
      <header className="wm-dashboard-heading">
        <div>
          <h1>Willkommen <span>zurück!</span></h1>
        </div>
      </header>

      <section className="wm-offer-composer" aria-labelledby="wm-offer-title">
        <div className="wm-offer-intro">
          <div className="wm-offer-icon" aria-hidden="true">
            <Mic size={22} />
          </div>
          <div>
            <h2 id="wm-offer-title">Neues Angebot erstellen</h2>
            <p>Beschreibe deinen Auftrag. Wir erstellen dir daraus einen Angebotsentwurf.</p>
          </div>
        </div>

        <div className="wm-customer-select-row">
          <label htmlFor="wm-customer-select">Wähle einen Kunden aus</label>
          <div className="wm-customer-select-controls">
            <select
              id="wm-customer-select"
              value={selectedCustomerId}
              onChange={(event) => setSelectedCustomerId(event.target.value)}
            >
              <option value="">Ohne Kunden – Demo-Vorschau</option>
              {customers.map((customer) => (
                <option key={customer.id} value={customer.id}>
                  {[customer.firstName, customer.lastName]
                    .filter(Boolean)
                    .join(" ")
                    .trim() || customer.email}
                  {customer.companyName ? ` · ${customer.companyName}` : ""}
                </option>
              ))}
            </select>
            <button
              className="wm-add-customer"
              type="button"
              onClick={() => navigate("/unternehmen?tab=kunde")}
            >
              <Plus size={16} aria-hidden="true" />
              Kunde anlegen
            </button>
          </div>
        </div>
        {customersError && (
          <p className="wm-dashboard-feedback wm-dashboard-error" role="alert">
            {customersError}
          </p>
        )}

        <div className="wm-offer-mode" role="group" aria-label="Eingabemethode">
          <button
            type="button"
            className={offerMode === "voice" ? "is-active" : ""}
            aria-pressed={offerMode === "voice"}
            onClick={() => setOfferMode("voice")}
          >
            Sprache
          </button>
          <button
            type="button"
            className={offerMode === "text" ? "is-active" : ""}
            aria-pressed={offerMode === "text"}
            onClick={() => setOfferMode("text")}
          >
            Text
          </button>
        </div>

        {offerMode === "voice" ? (
          <button
            className="wm-record-cta"
            type="button"
            onClick={() =>
              navigate("/home", {
                state: {
                  mode: "voice",
                  customerId: selectedCustomerId ? Number(selectedCustomerId) : null,
                },
              })
            }
          >
            <Mic size={17} aria-hidden="true" />
            Aufnahme starten
          </button>
        ) : (
          <div className="wm-dashboard-text">
            <textarea
              aria-label="Auftrag beschreiben"
              placeholder="Gib hier deinen Text ein und die KI wird dir ein passendes Angebot erstellen."
              value={offerText}
              onChange={(event) => setOfferText(event.target.value)}
            />
            <button
              type="button"
              onClick={() =>
                navigate("/home", {
                  state: {
                    mode: "text",
                    transcript: offerText,
                    customerId: selectedCustomerId ? Number(selectedCustomerId) : null,
                  },
                })
              }
            >
              Angebot erstellen
            </button>
          </div>
        )}
      </section>

      <DashboardOverview
        data={data}
        loading={loading}
        error={error}
        onShowAll={() => navigate("/dokumente")}
      />
    </div>
  );
};